/********************************************************************************
** Form generated from reading UI file 'mainWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QGraphicsView *graphicsView;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *ipAddressLabel;
    QLabel *serverStatusLabel;
    QPushButton *startGameButton;
    QPushButton *stopGameButton;
    QWidget *layoutWidget1;
    QGridLayout *gridLayout;
    QLabel *label;
    QLabel *p2imposterLabel;
    QLabel *p2nameLabel;
    QLabel *p5aliveLabel;
    QLabel *p4nameLabel;
    QLabel *p1imposterLabel;
    QLabel *p5imposterLabel;
    QLabel *p3aliveLabel;
    QLabel *p3numTasksLabel;
    QLabel *p1iconLabel;
    QLabel *p0imposterLabel;
    QLabel *p4imposterLabel;
    QLabel *label_3;
    QLabel *p1numTasksLabel;
    QLabel *p4iconLabel;
    QLabel *p3iconLabel;
    QLabel *p0numTasksLabel;
    QLabel *p0aliveLabel;
    QLabel *p2numTasksLabel;
    QLabel *p1aliveLabel;
    QLabel *p3imposterLabel;
    QLabel *p4aliveLabel;
    QLabel *p5nameLabel;
    QLabel *label_4;
    QLabel *p4numTasksLabel;
    QLabel *label_5;
    QLabel *p3nameLabel;
    QLabel *label_2;
    QLabel *p5iconLabel;
    QLabel *p2iconLabel;
    QLabel *p1nameLabel;
    QLabel *p0iconLabel;
    QLabel *p2aliveLabel;
    QLabel *p0nameLabel;
    QLabel *p5numTasksLabel;
    QLabel *label_6;
    QLabel *p0voteLabel;
    QLabel *p1voteLabel;
    QLabel *p2voteLabel;
    QLabel *p3voteLabel;
    QLabel *p4voteLabel;
    QLabel *p5voteLabel;

    void setupUi(QWidget *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1236, 826);
        graphicsView = new QGraphicsView(MainWindow);
        graphicsView->setObjectName(QString::fromUtf8("graphicsView"));
        graphicsView->setGeometry(QRect(270, 10, 931, 551));
        graphicsView->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        layoutWidget = new QWidget(MainWindow);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(40, 71, 170, 110));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        ipAddressLabel = new QLabel(layoutWidget);
        ipAddressLabel->setObjectName(QString::fromUtf8("ipAddressLabel"));

        verticalLayout->addWidget(ipAddressLabel);

        serverStatusLabel = new QLabel(layoutWidget);
        serverStatusLabel->setObjectName(QString::fromUtf8("serverStatusLabel"));

        verticalLayout->addWidget(serverStatusLabel);

        startGameButton = new QPushButton(layoutWidget);
        startGameButton->setObjectName(QString::fromUtf8("startGameButton"));

        verticalLayout->addWidget(startGameButton);

        stopGameButton = new QPushButton(layoutWidget);
        stopGameButton->setObjectName(QString::fromUtf8("stopGameButton"));

        verticalLayout->addWidget(stopGameButton);

        layoutWidget1 = new QWidget(MainWindow);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(430, 590, 511, 191));
        gridLayout = new QGridLayout(layoutWidget1);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget1);
        label->setObjectName(QString::fromUtf8("label"));
        label->setStyleSheet(QString::fromUtf8("font: 700 11pt \"Segoe UI\";"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        p2imposterLabel = new QLabel(layoutWidget1);
        p2imposterLabel->setObjectName(QString::fromUtf8("p2imposterLabel"));

        gridLayout->addWidget(p2imposterLabel, 3, 2, 1, 1);

        p2nameLabel = new QLabel(layoutWidget1);
        p2nameLabel->setObjectName(QString::fromUtf8("p2nameLabel"));

        gridLayout->addWidget(p2nameLabel, 3, 1, 1, 1);

        p5aliveLabel = new QLabel(layoutWidget1);
        p5aliveLabel->setObjectName(QString::fromUtf8("p5aliveLabel"));
        p5aliveLabel->setStyleSheet(QString::fromUtf8(""));

        gridLayout->addWidget(p5aliveLabel, 6, 4, 1, 1);

        p4nameLabel = new QLabel(layoutWidget1);
        p4nameLabel->setObjectName(QString::fromUtf8("p4nameLabel"));

        gridLayout->addWidget(p4nameLabel, 5, 1, 1, 1);

        p1imposterLabel = new QLabel(layoutWidget1);
        p1imposterLabel->setObjectName(QString::fromUtf8("p1imposterLabel"));

        gridLayout->addWidget(p1imposterLabel, 2, 2, 1, 1);

        p5imposterLabel = new QLabel(layoutWidget1);
        p5imposterLabel->setObjectName(QString::fromUtf8("p5imposterLabel"));

        gridLayout->addWidget(p5imposterLabel, 6, 2, 1, 1);

        p3aliveLabel = new QLabel(layoutWidget1);
        p3aliveLabel->setObjectName(QString::fromUtf8("p3aliveLabel"));
        p3aliveLabel->setStyleSheet(QString::fromUtf8(""));

        gridLayout->addWidget(p3aliveLabel, 4, 4, 1, 1);

        p3numTasksLabel = new QLabel(layoutWidget1);
        p3numTasksLabel->setObjectName(QString::fromUtf8("p3numTasksLabel"));

        gridLayout->addWidget(p3numTasksLabel, 4, 3, 1, 1);

        p1iconLabel = new QLabel(layoutWidget1);
        p1iconLabel->setObjectName(QString::fromUtf8("p1iconLabel"));
        p1iconLabel->setStyleSheet(QString::fromUtf8(""));

        gridLayout->addWidget(p1iconLabel, 2, 0, 1, 1);

        p0imposterLabel = new QLabel(layoutWidget1);
        p0imposterLabel->setObjectName(QString::fromUtf8("p0imposterLabel"));

        gridLayout->addWidget(p0imposterLabel, 1, 2, 1, 1);

        p4imposterLabel = new QLabel(layoutWidget1);
        p4imposterLabel->setObjectName(QString::fromUtf8("p4imposterLabel"));

        gridLayout->addWidget(p4imposterLabel, 5, 2, 1, 1);

        label_3 = new QLabel(layoutWidget1);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setStyleSheet(QString::fromUtf8("font: 700 11pt \"Segoe UI\";"));

        gridLayout->addWidget(label_3, 0, 2, 1, 1);

        p1numTasksLabel = new QLabel(layoutWidget1);
        p1numTasksLabel->setObjectName(QString::fromUtf8("p1numTasksLabel"));

        gridLayout->addWidget(p1numTasksLabel, 2, 3, 1, 1);

        p4iconLabel = new QLabel(layoutWidget1);
        p4iconLabel->setObjectName(QString::fromUtf8("p4iconLabel"));
        p4iconLabel->setStyleSheet(QString::fromUtf8(""));

        gridLayout->addWidget(p4iconLabel, 5, 0, 1, 1);

        p3iconLabel = new QLabel(layoutWidget1);
        p3iconLabel->setObjectName(QString::fromUtf8("p3iconLabel"));
        p3iconLabel->setStyleSheet(QString::fromUtf8(""));

        gridLayout->addWidget(p3iconLabel, 4, 0, 1, 1);

        p0numTasksLabel = new QLabel(layoutWidget1);
        p0numTasksLabel->setObjectName(QString::fromUtf8("p0numTasksLabel"));

        gridLayout->addWidget(p0numTasksLabel, 1, 3, 1, 1);

        p0aliveLabel = new QLabel(layoutWidget1);
        p0aliveLabel->setObjectName(QString::fromUtf8("p0aliveLabel"));
        p0aliveLabel->setStyleSheet(QString::fromUtf8(""));

        gridLayout->addWidget(p0aliveLabel, 1, 4, 1, 1);

        p2numTasksLabel = new QLabel(layoutWidget1);
        p2numTasksLabel->setObjectName(QString::fromUtf8("p2numTasksLabel"));

        gridLayout->addWidget(p2numTasksLabel, 3, 3, 1, 1);

        p1aliveLabel = new QLabel(layoutWidget1);
        p1aliveLabel->setObjectName(QString::fromUtf8("p1aliveLabel"));
        p1aliveLabel->setStyleSheet(QString::fromUtf8(""));

        gridLayout->addWidget(p1aliveLabel, 2, 4, 1, 1);

        p3imposterLabel = new QLabel(layoutWidget1);
        p3imposterLabel->setObjectName(QString::fromUtf8("p3imposterLabel"));

        gridLayout->addWidget(p3imposterLabel, 4, 2, 1, 1);

        p4aliveLabel = new QLabel(layoutWidget1);
        p4aliveLabel->setObjectName(QString::fromUtf8("p4aliveLabel"));
        p4aliveLabel->setStyleSheet(QString::fromUtf8(""));

        gridLayout->addWidget(p4aliveLabel, 5, 4, 1, 1);

        p5nameLabel = new QLabel(layoutWidget1);
        p5nameLabel->setObjectName(QString::fromUtf8("p5nameLabel"));

        gridLayout->addWidget(p5nameLabel, 6, 1, 1, 1);

        label_4 = new QLabel(layoutWidget1);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setStyleSheet(QString::fromUtf8("font: 700 11pt \"Segoe UI\";"));

        gridLayout->addWidget(label_4, 0, 3, 1, 1);

        p4numTasksLabel = new QLabel(layoutWidget1);
        p4numTasksLabel->setObjectName(QString::fromUtf8("p4numTasksLabel"));

        gridLayout->addWidget(p4numTasksLabel, 5, 3, 1, 1);

        label_5 = new QLabel(layoutWidget1);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setStyleSheet(QString::fromUtf8("font: 700 11pt \"Segoe UI\";"));

        gridLayout->addWidget(label_5, 0, 4, 1, 1);

        p3nameLabel = new QLabel(layoutWidget1);
        p3nameLabel->setObjectName(QString::fromUtf8("p3nameLabel"));

        gridLayout->addWidget(p3nameLabel, 4, 1, 1, 1);

        label_2 = new QLabel(layoutWidget1);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setStyleSheet(QString::fromUtf8("font: 700 11pt \"Segoe UI\";"));

        gridLayout->addWidget(label_2, 0, 1, 1, 1);

        p5iconLabel = new QLabel(layoutWidget1);
        p5iconLabel->setObjectName(QString::fromUtf8("p5iconLabel"));
        p5iconLabel->setStyleSheet(QString::fromUtf8(""));

        gridLayout->addWidget(p5iconLabel, 6, 0, 1, 1);

        p2iconLabel = new QLabel(layoutWidget1);
        p2iconLabel->setObjectName(QString::fromUtf8("p2iconLabel"));
        p2iconLabel->setStyleSheet(QString::fromUtf8(""));

        gridLayout->addWidget(p2iconLabel, 3, 0, 1, 1);

        p1nameLabel = new QLabel(layoutWidget1);
        p1nameLabel->setObjectName(QString::fromUtf8("p1nameLabel"));

        gridLayout->addWidget(p1nameLabel, 2, 1, 1, 1);

        p0iconLabel = new QLabel(layoutWidget1);
        p0iconLabel->setObjectName(QString::fromUtf8("p0iconLabel"));
        p0iconLabel->setStyleSheet(QString::fromUtf8(""));

        gridLayout->addWidget(p0iconLabel, 1, 0, 1, 1);

        p2aliveLabel = new QLabel(layoutWidget1);
        p2aliveLabel->setObjectName(QString::fromUtf8("p2aliveLabel"));
        p2aliveLabel->setStyleSheet(QString::fromUtf8(""));

        gridLayout->addWidget(p2aliveLabel, 3, 4, 1, 1);

        p0nameLabel = new QLabel(layoutWidget1);
        p0nameLabel->setObjectName(QString::fromUtf8("p0nameLabel"));

        gridLayout->addWidget(p0nameLabel, 1, 1, 1, 1);

        p5numTasksLabel = new QLabel(layoutWidget1);
        p5numTasksLabel->setObjectName(QString::fromUtf8("p5numTasksLabel"));

        gridLayout->addWidget(p5numTasksLabel, 6, 3, 1, 1);

        label_6 = new QLabel(layoutWidget1);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setStyleSheet(QString::fromUtf8("font: 700 11pt \"Segoe UI\";"));

        gridLayout->addWidget(label_6, 0, 5, 1, 1);

        p0voteLabel = new QLabel(layoutWidget1);
        p0voteLabel->setObjectName(QString::fromUtf8("p0voteLabel"));

        gridLayout->addWidget(p0voteLabel, 1, 5, 1, 1);

        p1voteLabel = new QLabel(layoutWidget1);
        p1voteLabel->setObjectName(QString::fromUtf8("p1voteLabel"));

        gridLayout->addWidget(p1voteLabel, 2, 5, 1, 1);

        p2voteLabel = new QLabel(layoutWidget1);
        p2voteLabel->setObjectName(QString::fromUtf8("p2voteLabel"));

        gridLayout->addWidget(p2voteLabel, 3, 5, 1, 1);

        p3voteLabel = new QLabel(layoutWidget1);
        p3voteLabel->setObjectName(QString::fromUtf8("p3voteLabel"));

        gridLayout->addWidget(p3voteLabel, 4, 5, 1, 1);

        p4voteLabel = new QLabel(layoutWidget1);
        p4voteLabel->setObjectName(QString::fromUtf8("p4voteLabel"));

        gridLayout->addWidget(p4voteLabel, 5, 5, 1, 1);

        p5voteLabel = new QLabel(layoutWidget1);
        p5voteLabel->setObjectName(QString::fromUtf8("p5voteLabel"));

        gridLayout->addWidget(p5voteLabel, 6, 5, 1, 1);


        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QWidget *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Form", nullptr));
        ipAddressLabel->setText(QApplication::translate("MainWindow", "Server IP: ", nullptr));
        serverStatusLabel->setText(QApplication::translate("MainWindow", "Server Status: ", nullptr));
        startGameButton->setText(QApplication::translate("MainWindow", "Start Game", nullptr));
        stopGameButton->setText(QApplication::translate("MainWindow", "Stop Game", nullptr));
        label->setText(QString());
        p2imposterLabel->setText(QString());
        p2nameLabel->setText(QString());
        p5aliveLabel->setText(QString());
        p4nameLabel->setText(QString());
        p1imposterLabel->setText(QString());
        p5imposterLabel->setText(QString());
        p3aliveLabel->setText(QString());
        p3numTasksLabel->setText(QString());
        p1iconLabel->setText(QString());
        p0imposterLabel->setText(QString());
        p4imposterLabel->setText(QString());
        label_3->setText(QApplication::translate("MainWindow", "role", nullptr));
        p1numTasksLabel->setText(QString());
        p4iconLabel->setText(QString());
        p3iconLabel->setText(QString());
        p0numTasksLabel->setText(QString());
        p0aliveLabel->setText(QString());
        p2numTasksLabel->setText(QString());
        p1aliveLabel->setText(QString());
        p3imposterLabel->setText(QString());
        p4aliveLabel->setText(QString());
        p5nameLabel->setText(QString());
        label_4->setText(QApplication::translate("MainWindow", "tasks", nullptr));
        p4numTasksLabel->setText(QString());
        label_5->setText(QApplication::translate("MainWindow", "alive/dead", nullptr));
        p3nameLabel->setText(QString());
        label_2->setText(QApplication::translate("MainWindow", "username", nullptr));
        p5iconLabel->setText(QString());
        p2iconLabel->setText(QString());
        p1nameLabel->setText(QString());
        p0iconLabel->setText(QString());
        p2aliveLabel->setText(QString());
        p0nameLabel->setText(QString());
        p5numTasksLabel->setText(QString());
        label_6->setText(QApplication::translate("MainWindow", "votes", nullptr));
        p0voteLabel->setText(QString());
        p1voteLabel->setText(QString());
        p2voteLabel->setText(QString());
        p3voteLabel->setText(QString());
        p4voteLabel->setText(QString());
        p5voteLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
