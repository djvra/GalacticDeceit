/****************************************************************************
** Meta object code from reading C++ file 'server.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "server.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'server.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Server_t {
    QByteArrayData data[22];
    char stringdata0[270];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Server_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Server_t qt_meta_stringdata_Server = {
    {
QT_MOC_LITERAL(0, 0, 6), // "Server"
QT_MOC_LITERAL(1, 7, 11), // "initPlayers"
QT_MOC_LITERAL(2, 19, 0), // ""
QT_MOC_LITERAL(3, 20, 20), // "QMap<int,ClientData>"
QT_MOC_LITERAL(4, 41, 7), // "clients"
QT_MOC_LITERAL(5, 49, 13), // "updateGameMap"
QT_MOC_LITERAL(6, 63, 12), // "updatePlayer"
QT_MOC_LITERAL(7, 76, 10), // "ClientData"
QT_MOC_LITERAL(8, 87, 6), // "client"
QT_MOC_LITERAL(9, 94, 17), // "updateVotedPlayer"
QT_MOC_LITERAL(10, 112, 2), // "id"
QT_MOC_LITERAL(11, 115, 8), // "numVotes"
QT_MOC_LITERAL(12, 124, 10), // "resetVotes"
QT_MOC_LITERAL(13, 135, 8), // "newLogin"
QT_MOC_LITERAL(14, 144, 22), // "handleNewTcpConnection"
QT_MOC_LITERAL(15, 167, 13), // "handleTcpData"
QT_MOC_LITERAL(16, 181, 11), // "QTcpSocket*"
QT_MOC_LITERAL(17, 193, 6), // "socket"
QT_MOC_LITERAL(18, 200, 18), // "handleUdpDatagrams"
QT_MOC_LITERAL(19, 219, 22), // "sendPlayerStartingInfo"
QT_MOC_LITERAL(20, 242, 14), // "sendPlayerData"
QT_MOC_LITERAL(21, 257, 12) // "handleReport"

    },
    "Server\0initPlayers\0\0QMap<int,ClientData>\0"
    "clients\0updateGameMap\0updatePlayer\0"
    "ClientData\0client\0updateVotedPlayer\0"
    "id\0numVotes\0resetVotes\0newLogin\0"
    "handleNewTcpConnection\0handleTcpData\0"
    "QTcpSocket*\0socket\0handleUdpDatagrams\0"
    "sendPlayerStartingInfo\0sendPlayerData\0"
    "handleReport"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Server[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   74,    2, 0x06 /* Public */,
       5,    1,   77,    2, 0x06 /* Public */,
       6,    1,   80,    2, 0x06 /* Public */,
       9,    2,   83,    2, 0x06 /* Public */,
      12,    0,   88,    2, 0x06 /* Public */,
      13,    1,   89,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      14,    0,   92,    2, 0x08 /* Private */,
      15,    1,   93,    2, 0x08 /* Private */,
      18,    0,   96,    2, 0x08 /* Private */,
      19,    0,   97,    2, 0x08 /* Private */,
      20,    0,   98,    2, 0x08 /* Private */,
      21,    0,   99,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 7,    8,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   10,   11,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 7,    8,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 16,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Server::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Server *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->initPlayers((*reinterpret_cast< QMap<int,ClientData>(*)>(_a[1]))); break;
        case 1: _t->updateGameMap((*reinterpret_cast< QMap<int,ClientData>(*)>(_a[1]))); break;
        case 2: _t->updatePlayer((*reinterpret_cast< ClientData(*)>(_a[1]))); break;
        case 3: _t->updateVotedPlayer((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 4: _t->resetVotes(); break;
        case 5: _t->newLogin((*reinterpret_cast< ClientData(*)>(_a[1]))); break;
        case 6: _t->handleNewTcpConnection(); break;
        case 7: _t->handleTcpData((*reinterpret_cast< QTcpSocket*(*)>(_a[1]))); break;
        case 8: _t->handleUdpDatagrams(); break;
        case 9: _t->sendPlayerStartingInfo(); break;
        case 10: _t->sendPlayerData(); break;
        case 11: _t->handleReport(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QTcpSocket* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Server::*)(QMap<int,ClientData> );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Server::initPlayers)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (Server::*)(QMap<int,ClientData> );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Server::updateGameMap)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (Server::*)(ClientData );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Server::updatePlayer)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (Server::*)(int , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Server::updateVotedPlayer)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (Server::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Server::resetVotes)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (Server::*)(ClientData );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Server::newLogin)) {
                *result = 5;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Server::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_Server.data,
    qt_meta_data_Server,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Server::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Server::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Server.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int Server::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    }
    return _id;
}

// SIGNAL 0
void Server::initPlayers(QMap<int,ClientData> _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Server::updateGameMap(QMap<int,ClientData> _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Server::updatePlayer(ClientData _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void Server::updateVotedPlayer(int _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void Server::resetVotes()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void Server::newLogin(ClientData _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
